test_cases = r"""
>>> print "ok"
ok
"""
